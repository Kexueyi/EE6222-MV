import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from numpy.linalg import inv

# Load and preprocess the data
iris = datasets.load_iris()
X = iris.data
y = iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# PCA and LDA
pca = PCA(n_components=2)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.transform(X_test)
lda = LDA(n_components=2)
X_train_lda = lda.fit_transform(X_train, y_train)
X_test_lda = lda.transform(X_test)

# Mahalanobis Distance Classifier
class MahalanobisClassifier:
    def __init__(self):
        self.means = {}
        self.inverses = {}
        self.classes = []
        
    def fit(self, X, y):
        self.classes = np.unique(y)
        for c in self.classes:
            data_c = X[y == c]
            self.means[c] = np.mean(data_c, axis=0)
            cov_matrix = np.cov(data_c, rowvar=False)
            self.inverses[c] = inv(cov_matrix)
    
    def predict(self, X):
        predictions = []
        for x in X:
            distances = []
            for c in self.classes:
                diff = x - self.means[c]
                distance = diff.T @ self.inverses[c] @ diff
                distances.append(distance)
            predictions.append(self.classes[np.argmin(distances)])
        return np.array(predictions)

classifier = MahalanobisClassifier()
classifier.fit(X_train_pca, y_train)
y_pred_pca = classifier.predict(X_test_pca)
classifier.fit(X_train_lda, y_train)
y_pred_lda = classifier.predict(X_test_lda)

accuracy_pca = accuracy_score(y_test, y_pred_pca)
accuracy_lda = accuracy_score(y_test, y_pred_lda)

# Compute confusion matrix and other metrics
confusion_pca = confusion_matrix(y_test, y_pred_pca)
confusion_lda = confusion_matrix(y_test, y_pred_lda)

print("\nPCA Confusion Matrix:\n", confusion_pca)
print("\nLDA Confusion Matrix:\n", confusion_lda)

print("\nPCA Classification Report:\n", classification_report(y_test, y_pred_pca))
print("\nLDA Classification Report:\n", classification_report(y_test, y_pred_lda))
print(f"PCA Accuracy: {accuracy_pca * 100:.2f}%")
print(f"LDA Accuracy: {accuracy_lda * 100:.2f}%")

# Visualization
def plot_transformed_data(X, y, title):
    plt.figure(figsize=(8, 6))
    for i, c in enumerate(np.unique(y)):
        plt.scatter(X[y == c, 0], X[y == c, 1], label=f"Class {c}", edgecolors='k')
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.legend()
    plt.grid(True)
    plt.show()


def plot_transformed_data(X, y, title, filename):
    plt.figure(figsize=(8, 6))
    for i, c in enumerate(np.unique(y)):
        plt.scatter(X[y == c, 0], X[y == c, 1], label=f"Class {c}", edgecolors='k')
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.legend()
    plt.grid(True)
    plt.savefig(filename)
    plt.close()

plot_transformed_data(X_train_pca, y_train, "PCA Transformed Iris Data", "PCA_Transformed_Iris_Data.png")
plot_transformed_data(X_train_lda, y_train, "LDA Transformed Iris Data", "LDA_Transformed_Iris_Data.png")
