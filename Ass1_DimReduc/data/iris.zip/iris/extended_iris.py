import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from numpy.linalg import inv

from matplotlib.colors import ListedColormap
# Load and preprocess the data
iris = datasets.load_iris()
X = iris.data
y = iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# PCA and LDA
pca = PCA(n_components=2)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.transform(X_test)
lda = LDA(n_components=2)
X_train_lda = lda.fit_transform(X_train, y_train)
X_test_lda = lda.transform(X_test)

# Mahalanobis Distance Classifier
class MahalanobisClassifier:
    def __init__(self):
        self.means = {}
        self.inverses = {}
        self.classes = []
        
    def fit(self, X, y):
        self.classes = np.unique(y)
        for c in self.classes:
            data_c = X[y == c]
            self.means[c] = np.mean(data_c, axis=0)
            cov_matrix = np.cov(data_c, rowvar=False)
            self.inverses[c] = inv(cov_matrix)
    
    def predict(self, X):
        predictions = []
        for x in X:
            distances = []
            for c in self.classes:
                diff = x - self.means[c]
                distance = diff.T @ self.inverses[c] @ diff
                distances.append(distance)
            predictions.append(self.classes[np.argmin(distances)])
        return np.array(predictions)

classifier = MahalanobisClassifier()
classifier.fit(X_train_pca, y_train)
y_pred_pca = classifier.predict(X_test_pca)
classifier.fit(X_train_lda, y_train)
y_pred_lda = classifier.predict(X_test_lda)

accuracy_pca = accuracy_score(y_test, y_pred_pca)
accuracy_lda = accuracy_score(y_test, y_pred_lda)

# Compute confusion matrix and other metrics
confusion_pca = confusion_matrix(y_test, y_pred_pca)
confusion_lda = confusion_matrix(y_test, y_pred_lda)

print(f"PCA Accuracy: {accuracy_pca * 100:.2f}%")
print(f"LDA Accuracy: {accuracy_lda * 100:.2f}%")


# Visualize feature distribution
features = iris.feature_names
for i, feature in enumerate(features):
    plt.figure(figsize=(8, 6))
    sns.histplot(X_train[:, i], kde=True, bins=30)
    plt.title(f"Distribution of {feature}")
    plt.xlabel(feature)
    plt.ylabel("Frequency")
    plt.grid(True)
    plt.savefig(f"Distribution_of_{feature.replace(' ', '_')}.png")
    plt.close()

# Visualize class distribution
plt.figure(figsize=(8, 6))
sns.countplot(y_train)
plt.title("Class Distribution")
plt.xlabel("Class")
plt.ylabel("Count")
plt.grid(True)
plt.savefig("Class_Distribution.png")
plt.close()

# Visualize feature relationships
sns.pairplot(pd.DataFrame(X_train, columns=features), diag_kind="kde")
plt.suptitle("Feature Relationships with Pairplot", y=1.02)
plt.savefig("Feature_Relationships_Pairplot.png")
plt.close()

def plot_decision_boundary(X, y, classifier, title):
    h = .02
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    Z = classifier.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.figure(figsize=(8, 6))
    plt.contourf(xx, yy, Z, alpha=0.8, cmap=ListedColormap(('red', 'green', 'blue')))
    plt.scatter(X[:, 0], X[:, 1], c=y, edgecolors='k', marker='o')
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.grid(True)
    plt.savefig(f"Decision_Boundary_{title.replace(' ', '_')}.png")
    plt.close()

# Decision boundaries for PCA and LDA
classifier.fit(X_train_pca, y_train)
plot_decision_boundary(X_train_pca, y_train, classifier, "Decision Boundary for PCA")
classifier.fit(X_train_lda, y_train)
plot_decision_boundary(X_train_lda, y_train, classifier, "Decision Boundary for LDA")

# Visualize confusion matrices
def plot_confusion_matrix(cm, title):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title(title)
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.savefig(f"Confusion_Matrix_{title.replace(' ', '_')}.png")
    plt.close()

plot_confusion_matrix(confusion_pca, "Confusion Matrix for PCA")
plot_confusion_matrix(confusion_lda, "Confusion Matrix for LDA")



# Visualization
def plot_transformed_data(X, y, title):
    plt.figure(figsize=(8, 6))
    for i, c in enumerate(np.unique(y)):
        plt.scatter(X[y == c, 0], X[y == c, 1], label=f"Class {c}", edgecolors='k')
    plt.title(title)
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.legend()
    plt.grid(True)
    plt.savefig('PCA_Transformed_Iris_Data.png')

plot_transformed_data(X_train_pca, y_train, "PCA Transformed Iris Data")
plot_transformed_data(X_train_lda, y_train, "LDA Transformed Iris Data")

